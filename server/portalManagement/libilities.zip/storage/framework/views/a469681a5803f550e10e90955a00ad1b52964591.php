<?php if($isModelTranslatable): ?>
    <input type="hidden"
           data-i18n="true"
           name="<?php echo e($_field_name); ?>_i18n"
           id="<?php echo e($_field_name); ?>_i18n"
           value="<?php echo e($_field_trans); ?>">
<?php endif; ?>
<?php /**PATH /media/ibrahim/01D637928D784270/UPWORK/portalManagement/server/portalManagement/vendor/tcg/voyager/src/../resources/views/multilingual/input-hidden.blade.php ENDPATH**/ ?>